//package com.example.simda
//
//data class Person(val money: String?, val name: String?)