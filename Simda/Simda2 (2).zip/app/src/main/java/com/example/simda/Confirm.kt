package com.example.simda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_confirm.*
import kotlinx.android.synthetic.main.activity_input_money.*

class Confirm : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirm)

        //값 가져오기
        if ((intent.hasExtra("money_key")) and (intent.hasExtra("friend_key"))) {
            money_text.text = intent.getStringExtra("money_key")
            friend_text.text = intent.getStringArrayListExtra("friend_key").toString()
//            textView8.text = intent.getStringArrayExtra("friend_key").toString()

        }
    }

    //값 보내기
    //우선은 list_progress로 보내는데, 이쪽 구현 끝나면 친구에게 알리기로 보내야함
    fun start_list_progress_2(view : View){
        //add_money = editText_money.text.toString()
        val intent = Intent(this, list_progress::class.java)
        intent.putExtra("money_key", add_money)
        //intent.putExtra("friend_key", friend_list)
        intent.putExtra("friend_key_text", friend_text.text.toString())
        startActivity(intent)
    }
}