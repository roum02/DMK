package com.example.simda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_input_friend.*
import kotlinx.android.synthetic.main.activity_list_progress.*

//var friend_list = arrayListOf<String>()

class Input_friend : AppCompatActivity(), AdapterView.OnItemClickListener {

    var friend_list = arrayListOf<String>()
    lateinit var adapter: ArrayAdapter<String>
    var idx_sel = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_friend)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, friend_list)
        listView_friend.setAdapter(adapter)
        listView_friend.setOnItemClickListener(this)

//        값 가져오기
//        if (intent.hasExtra("money_key")) {
//            textView8.text = intent.getStringExtra("money_key")
//        }
    }

    fun add_list(view: View){
        val add_friend = editText_friend.text.toString()
        friend_list.add(add_friend)
        adapter.notifyDataSetChanged()
    }

    fun del_item(view: View){
        friend_list.removeAt(idx_sel)
        adapter.notifyDataSetChanged()
    }

    override fun onItemClick(
        parent: AdapterView<*>, view: View, position: Int, id: Long) {
        idx_sel = position
    }

    //값 보내기
    fun start_Confirm(view : View){
        //val add_money = editText_money.text.toString()
        val intent = Intent(this, Confirm::class.java)
        intent.putExtra("money_key", add_money)
        intent.putExtra("friend_key", friend_list)
        startActivity(intent)
    }


}
