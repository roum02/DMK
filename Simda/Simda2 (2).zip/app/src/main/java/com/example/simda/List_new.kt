package com.example.simda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class List_new : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_new)
    }

    fun start_input_money(view : View){
        var intent = Intent(this, Input_money::class.java)
        startActivity(intent)
    }
}