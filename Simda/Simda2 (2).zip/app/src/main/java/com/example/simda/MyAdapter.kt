//package com.example.simda
//
//import android.content.Context
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.ArrayAdapter
//import android.widget.TextView
//
//data class MyData(var profile: Int, var money : String, var name : String)
//
//class MyAdapter(context: Context, list: MutableList<MyData>) :
//    ArrayAdapter<MyData>(context, 0, list){
//
//    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
//
//        var data = getItem(position)
//
//        var a = LayoutInflater.from(context)
//
//        var view = convertView
//        if(view == null){
//            view = a.inflate(R.layout.list_row, parent, false);
//        }
//
//        var money_adapter = view!!.findViewById<TextView>(R.id.list_money)
//        var name_adapter = view!!.findViewById<TextView>(R.id.list_name)
//
//        money_adapter.text = data.name
//        name_adapter.text = data.money
//
//        return view
//    }
//}