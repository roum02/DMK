package com.example.simda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_list_progress.*

class List_finish : AppCompatActivity() {

    lateinit var adapter : UserAdapter
    var idx_sel = 0

    var finishListNew = arrayListOf<User>(
        User(R.drawable.ic_ellipse_1, name = add_name, money = add_money)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_finish)

        val Adapter = UserAdapter(this, finishListNew)
        listView.adapter = Adapter

        //값 가져오기
        //add_name을 보냈는데 friend_key_text를 가져오는 거가 이상하긴 한데 돌아가니까 그냥 놔두는 코드
        if ((intent.hasExtra("money_key")) and (intent.hasExtra("friend_key_text"))) {
            add_money = intent.getStringExtra("money_key").toString()
            add_name = intent.getStringExtra("friend_key_text").toString()
        }

        //리스트 더하기
//        add_btn.setOnClickListener(){
//            UserList.add(User(R.drawable.ic_ellipse_1, name = add_name, money = add_money))
//            Adapter.notifyDataSetChanged()
//        }

        //리스트 빼기
        del_btn.setOnClickListener(){
            //finishList에 추가
            //finishList.add(User(R.drawable.ic_ellipse_1, name = add_name, money = add_money))
            finishListNew.removeAt(idx_sel)
            Adapter.notifyDataSetChanged()
        }

    }

    fun start_list_progress(view : View){
        var intent = Intent(this, list_progress::class.java)
        startActivity(intent)
    }
}