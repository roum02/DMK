package com.example.simda

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.LinearLayout
import com.example.simda.R

class list_row : LinearLayout {
    constructor(context: Context?) : super(context){
        onInit(context)
    }
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs){
        onInit(context)
    }

    fun onInit(context: Context?){
        LayoutInflater.from(context).inflate(R.layout.list_row, this, true)
    }
}