//package com.example.simda
//
//import android.view.View
//import android.view.ViewGroup
//import androidx.recyclerview.widget.RecyclerView
//import kotlinx.android.synthetic.main.activity_list_progress.view.*
//
//class PersonAdapter : RecyclerView.Adapter<PersonAdapter.ViewHolder>() {
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PersonAdapter.ViewHolder {
//        TODO("Not yet implemented")
//    }
//
//    override fun onBindViewHolder(holder: PersonAdapter.ViewHolder, position: Int) {
//        TODO("Not yet implemented")
//    }
//
//    override fun getItemCount(): Int {
//        TODO("Not yet implemented")
//    }
//
//    inner class ViewHholder(itemView: View) : RecyclerView.ViewHolder(itemView){
//        fun setItem(item: Person){
//            itemView.textView.text = item.money
//            itemView.textView2.text = item.name
//        }
//    }
//
//}