package com.example.simda
//data추가, 하나의 데이터 타입으로 사용
data class User (val profile: Int, val name: String, val money: String)