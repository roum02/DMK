package com.example.simda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_list_progress.*

var add_name = ""
var add_money = ""

class list_progress : AppCompatActivity() {

    lateinit var adapter : UserAdapter
    var idx_sel = 0
//    var add_name = ""
//    var add_money = ""

//      var UserList = mutableListOf<User>(
    var UserList = arrayListOf<User>(
        User(R.drawable.ic_ellipse_1, name = "김철수", money = "30000"),
        User(R.drawable.ic_ellipse_1, name = "이미향, 박동수", money = "50000")
//        User(R.drawable.ic_ellipse_1, name = "박동수", money = "6000"),
//        User(R.drawable.ic_ellipse_1, name = "김라희", money = "8000")
    )

    //var finishList = arrayListOf<User>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_progress)

        val Adapter = UserAdapter(this, UserList)
        listView.adapter = Adapter

        //코틀린 리스트뷰 추가
//        listView.setOnItemClickListener { parent, view, position, id ->
//            //textView의 text정보를 선택한 listView의 텍스트값으로 변경
//            textView.text = listView.getItemAtPosition(position) as CharSequence
//        }

        //리스트 더하기
       add_btn.setOnClickListener(){
            UserList.add(User(R.drawable.ic_ellipse_1, name = add_name, money = add_money))
            Adapter.notifyDataSetChanged()
        }

        //리스트 빼기
        del_btn.setOnClickListener(){
            //finishList에 추가
            //finishList.add(User(R.drawable.ic_ellipse_1, name = add_name, money = add_money))
            UserList.removeAt(idx_sel)
            Adapter.notifyDataSetChanged()
        }

        //값 가져오기
        if ((intent.hasExtra("money_key")) and (intent.hasExtra("friend_key_text"))) {
            add_money = intent.getStringExtra("money_key").toString()
            add_name = intent.getStringExtra("friend_key_text").toString()
        }

        //클릭했을 때 밑에 알림이 뜨는 것
        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, ld ->
            val selectItem = parent.getItemAtPosition(position) as User
            Toast.makeText(this, selectItem.name, Toast.LENGTH_SHORT).show()
            idx_sel = position
        }

    }

    fun start_list_new(view : View){
        var intent = Intent(this, List_new::class.java)
        startActivity(intent)
    }

    //값 보내기
    fun start_list_finish(view: View){
        var intent = Intent(this, List_finish::class.java)
        intent.putExtra("money_key", com.example.simda.add_money)
        intent.putExtra("name_key", com.example.simda.add_name)
        //intent.putExtra("friend_key", friend_list)
        startActivity(intent)
    }

//    fun add_item(view: View){
//        UserList.add(User(R.drawable.ic_ellipse_1, name = add_name, money = add_money))
//        adapter.notifyDataSetChanged()
//    }

//    fun del_item(view: View){
//        UserList.removeAt(idx_sel)
//        adapter.notifyDataSetChanged()
//    }

//    fun onItemClick(parent: AdapterView<*>, view: View, position: Int, id: Long){
//        textView.setText("click : "+position+", " + UserList[position].name)
//        idx_sel = position
//    }


}