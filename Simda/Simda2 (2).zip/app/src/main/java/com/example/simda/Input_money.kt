package com.example.simda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_input_money.*
import kotlinx.android.synthetic.main.activity_list_progress.*

//var add_money = ""

class Input_money : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_money)

        //값 가져오기
//        if (intent.hasExtra("money_key")) {
//            textView.text = intent.getStringExtra("money_key")
//        }

    }

    //값 보내기
    fun start_input_friend(view : View){
        add_money = editText_money.text.toString()
        val intent = Intent(this, Input_friend::class.java)
        intent.putExtra("money_key", add_money)
        startActivity(intent)
    }

}