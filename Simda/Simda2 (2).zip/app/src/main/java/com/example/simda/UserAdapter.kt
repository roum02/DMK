package com.example.simda

import  android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

//class UserAdapter (val context: Context, val UserList: MutableList<User>) : BaseAdapter(){
class UserAdapter (val context: Context, val UserList: ArrayList<User>) : BaseAdapter(){

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = LayoutInflater.from(context).inflate(R.layout.list_row,null)

        val profile = view.findViewById<ImageView>(R.id.id_profile)
        val name = view.findViewById<TextView>(R.id.list_name)
        val money = view.findViewById<TextView>(R.id.list_money)

        //어레이 리스트의 포지션을 가지고 있는 변수
        val user = UserList[position]

        profile.setImageResource(user.profile)
        name.text = user.name
        money.text = user.money

        return view
    }

    override fun getItem(position: Int): Any {
        return UserList[position]
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getCount(): Int {
        return UserList.size
    }


}