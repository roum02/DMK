package com.example.covid19

import android.media.AudioManager
import android.media.SoundPool
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_happyending.*
import kotlinx.android.synthetic.main.activity_step1.*
import kotlinx.android.synthetic.main.activity_happyending.score3 as score31
import kotlinx.android.synthetic.main.activity_step1.user_name as user_name1

class Happyending : AppCompatActivity() {

    var sp = SoundPool(2, AudioManager.STREAM_MUSIC, 0)
    var note = IntArray(2)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_happyending)

        if (intent.hasExtra("score") and intent.hasExtra("user")) {
            score3.text = intent.getStringExtra("score")
            user_name.text = intent.getStringExtra("user")
        }

        note[0] = sp.load(this, R.raw.wrong,1)
        note[1] = sp.load(this, R.raw.right,1)

        //textView.text = number.toString()
        if(number.toInt() <= 0){
            result.text = "안타깝게도 감염되었습니다."
        }else if(number.toInt() <= 60){
            result.text = "아슬아슬하게 살아남았습니다."
        }
        else if(number.toInt() >60 ){
            result.text = "훌륭한 결과입니다! 축하합니다!"
        }
    }

    fun answer1(view: View){
        explain.text = "암호는 ONE, TWO, THREE, FOUR, FIVE, SIX 의 두 번째 알파벳을 의미하기 때문에, 답은 I 입니다."
    }

    fun answer2(view: View) {
        explain.text = "숫자들은 윗줄에 13개, 아랫줄에 13개 총 26개 이며 알파벳과 대응됩니다.\n" +
                "한글로 적어보았을 때 글자수를 의미하는 숫자입니다. 따라서 문제의 답은 W, 더블유. 즉 3입니다."
    }

    fun answer3(view: View){
        explain.text = "다이어리에 적힌 숫자는 각 알파벳을 완성할 수 있는 최소한의 획수를 모두 더한 값입니다. " +
                "\n 예를 들어, M, O, N 는 모두 한 번에 그을 수 있으므로 3인 것입니다. " +
                "따라서 T H U 문제의 정답은 6이 됩니다."
    }

}