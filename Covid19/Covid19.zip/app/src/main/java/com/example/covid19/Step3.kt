package com.example.covid19

import android.content.Intent
import android.media.AudioManager
import android.media.SoundPool
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_step1.*
import kotlinx.android.synthetic.main.activity_step1.gameover
import kotlinx.android.synthetic.main.activity_step1.next
import kotlinx.android.synthetic.main.activity_step1.popup
import kotlinx.android.synthetic.main.activity_step2.*
import kotlinx.android.synthetic.main.activity_step3.*
import kotlinx.android.synthetic.main.activity_step3.buttonPause
import kotlinx.android.synthetic.main.activity_step3.buttonStart
import kotlinx.android.synthetic.main.activity_step3.score3
import kotlinx.android.synthetic.main.activity_step3.textTimer
import kotlinx.android.synthetic.main.activity_step3.user_name
import kotlin.concurrent.thread
import kotlinx.android.synthetic.main.activity_step1.buttonPause as buttonPause1
import kotlinx.android.synthetic.main.activity_step1.buttonStart as buttonStart1
import kotlinx.android.synthetic.main.activity_step1.hint as hint1
import kotlinx.android.synthetic.main.activity_step1.score3 as score31
import kotlinx.android.synthetic.main.activity_step1.textTimer as textTimer1
import kotlinx.android.synthetic.main.activity_step1.user_name as user_name1
import kotlinx.android.synthetic.main.activity_step3.hint as hint1
import kotlinx.android.synthetic.main.activity_step3.next as next1
import kotlinx.android.synthetic.main.activity_step3.popup as popup1

class Step3 : AppCompatActivity() {

    var sp = SoundPool(2, AudioManager.STREAM_MUSIC, 0)
    var note = IntArray(2)

    var total = 120
    var started = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_step3)
        gameover.visibility = View.INVISIBLE
        stepthree.visibility = View.INVISIBLE

        if (intent.hasExtra("score") and intent.hasExtra("user")) {
            score3.text = intent.getStringExtra("score")
            user_name.text = intent.getStringExtra("user")
        }

        note[0] = sp.load(this, R.raw.wrong,1)
        note[1] = sp.load(this, R.raw.right,1)

        buttonStart.setOnClickListener{ start() }

        buttonPause.setOnClickListener{ pause() }

        next.setOnClickListener {
            val intent = Intent(this, Happyending::class.java)
            intent.putExtra("score", score3.text.toString())
            intent.putExtra("user",user_name.text.toString())
            startActivity(intent)
    }

}
    fun input(view: View){
        var a = editText.text.toString()
        if(a == "6"){
            score3.text = "${number.toInt() +30}"
            textView5.text = "정답입니다"
            sp.play(note[1], 1.0f, 1.0f, 0, 0, 1.0f)
        } else{
            number ="${number.toInt() - 20}"
            score3.text = number
            textView5.text = "오답입니다"
            if(number.toInt() <= 0){
                gameover.visibility = View.VISIBLE
            }
            sp.play(note[0], 1.0f, 1.0f, 0, 0, 1.0f)
        }
    }

    fun hint(view: View){
        hint.text = "알파벳과 획수를 대응시키시오"
    }


    fun start(){
        started = true
        thread(start=true) {
            while (true){
                Thread.sleep(1000)
                if(!started) break
                total = total - 1
                runOnUiThread{
                    textTimer.text = formatTime(total)
                    if(total == 0){
                        started = false
                        popup.text = "시간 초과 되었습니다.\n" +
                                " 다음으로 넘어가주세요."
                        gameover.visibility = View.VISIBLE
                    } else{
                        popup.text = "세 번째 문제입니다.\n" +
                                "요일마다 적힌 물음표 안의 숫자를 맞추시오.\n"
                        stepthree.visibility = View.VISIBLE
                    }

                }
            }
        }
    }

    fun pause(){
        started = false

    }

    fun stop(){
        started = false
        total = 0
        textTimer.text = "00 : 00"

    }

    fun formatTime(time:Int) : String{
        val minute = String.format("%02d", time/60)
        val second = String.format("%02d", time%60)
        return "$minute : $second"
    }


}
