package com.example.covid19

import android.content.Intent
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_step1.*
import kotlinx.android.synthetic.main.activity_step1.buttonPause
import kotlinx.android.synthetic.main.activity_step1.buttonStart
import kotlinx.android.synthetic.main.activity_step1.next
import kotlinx.android.synthetic.main.activity_step1.textTimer
import kotlinx.android.synthetic.main.activity_user_data.*
import kotlinx.coroutines.NonCancellable.start
import kotlin.concurrent.thread



class Step1 : AppCompatActivity() {

    var total = 120
    var started = false

    var sp = SoundPool(2, AudioManager.STREAM_MUSIC, 0)
    var note = IntArray(2)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_step1)
        gameover.visibility = View.INVISIBLE
        stepone.visibility = View.INVISIBLE

        if (intent.hasExtra("user")) {
            //textTimer.text = intent.getStringExtra("timer")
            user_name.text = intent.getStringExtra("user")
        }

        buttonStart.setOnClickListener{ start() }

        buttonPause.setOnClickListener{ pause() }

        note[0] = sp.load(this, R.raw.wrong,1)
        note[1] = sp.load(this, R.raw.right,1)

        next.setOnClickListener{
            val intent = Intent(this, Step2::class.java)
            intent.putExtra("score",score3.text.toString())
            intent.putExtra("user",user_name.text.toString())
            startActivity(intent)

        }

    }



    fun choice1(view: View){
        sp.play(note[0], 1.0f, 1.0f, 0, 0, 1.0f)
        number ="${50 - 15}"
        score3.text = number
        text.text = "오답입니다. 다음 버튼을 눌러주세요"
    }

    fun choice2(view: View){
        sp.play(note[1], 1.0f, 1.0f, 0, 0, 1.0f)
        number ="${50 + 20}"
        score3.text = number
        text.text = "정답입니다! 다음 버튼을 눌러주세요!"
    }

    fun choice3(view: View){
        sp.play(note[0], 1.0f, 1.0f, 0, 0, 1.0f)
        number ="${50 - 15}"
        score3.text = number
        text.text = "오답입니다. 다음 버튼을 눌러주세요"
    }

    fun hint(view: View){
        hint.text = "영어로 쓰인 숫자를 생각해보라"
    }

    fun start(){
        started = true
        thread(start=true) {
            while (true){
                Thread.sleep(1000)
                if(!started) break
                total = total - 1
                runOnUiThread{
                    textTimer.text = formatTime(total)
                    if(total == 0){
                        started = false
                        popup.text = "시간 초과 되었습니다. \n 다음 문제를 클릭해주세요."
                        gameover.visibility = View.VISIBLE
                    } else{
                        popup.text = "첫 번째 문제입니다.\n" +
                                "다음 암호의 빈칸을 맞추세요."
                        stepone.visibility = View.VISIBLE
                    }

                }
            }
        }
    }

    fun pause(){
        started = false

    }

    fun stop(){
        started = false
        total = 0
        textTimer.text = "00 : 00"

    }

    fun formatTime(time:Int) : String{
        val minute = String.format("%02d", time/60)
        val second = String.format("%02d", time%60)
        return "$minute : $second"
    }

    /*fun gameover(view: View) {
        var intent = Intent(this, Happyending::class.java)
        startActivity(intent)
    }*/


}