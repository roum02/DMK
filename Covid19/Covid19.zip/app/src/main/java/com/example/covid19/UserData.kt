package com.example.covid19

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.view.View
import kotlinx.android.synthetic.main.activity_step1.*
import kotlinx.android.synthetic.main.activity_step3.*
import kotlinx.android.synthetic.main.activity_step3.editText
import kotlinx.android.synthetic.main.activity_step3.score3
import kotlinx.android.synthetic.main.activity_user_data.*
import kotlin.concurrent.thread
import kotlinx.android.synthetic.main.activity_step1.buttonStart as buttonStart1
import kotlinx.android.synthetic.main.activity_step1.next as next1
import kotlinx.android.synthetic.main.activity_step1.textTimer as textTimer1
import kotlinx.android.synthetic.main.activity_step3.buttonPause as buttonPause1
import kotlinx.android.synthetic.main.activity_step3.textTimer as textTimer1
import kotlinx.android.synthetic.main.activity_user_data.buttonPause as buttonPause1
import kotlinx.android.synthetic.main.activity_user_data.next as next1

var number = ""


class UserData : AppCompatActivity() {

    var total = 0
    var started = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_data)
        rule.visibility = View.INVISIBLE
        next.visibility = View.INVISIBLE

        //buttonStart.setOnClickListener{ start() }

        buttonPause.setOnClickListener{ pause() }

        /*buttonStop.setOnClickListener{
            stop()
        }*/

        next.setOnClickListener {
            val intent = Intent(this, Step1::class.java)
            //intent.putExtra("timer", textTimer.text.toString())
            intent.putExtra("user", name.text.toString())
            startActivity(intent)

        }

    }

    fun name_btn(view: View) {
        var user_name = editText.text.toString()
        name.text = user_name
    }

    fun rule(view: View){
        next.visibility = View.VISIBLE
        rule.visibility = View.VISIBLE
    }

    /*fun startGame(view: View) {
        var intent = Intent(this, Step1::class.java)
        startActivity(intent)
    }*/


    fun start(){
        started = true
        thread(start=true) {
            while (true){
                Thread.sleep(1000)
                if(!started) break
                total = total + 1
                runOnUiThread{
                    textTimer.text = formatTime(total)
                }
            }
        }
    }

    fun pause(){
        started = false

    }

    fun stop(){
        started = false
        total = 0
        textTimer.text = "00 : 00"

    }

    fun formatTime(time:Int) : String{
        val minute = String.format("%02d", time/60)
        val second = String.format("%02d", time%60)
        return "$minute : $second"
    }
}